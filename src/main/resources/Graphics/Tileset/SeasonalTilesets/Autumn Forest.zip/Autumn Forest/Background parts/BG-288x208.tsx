<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="BG-288x208" tilewidth="16" tileheight="16" tilecount="234" columns="18">
 <image source="_Complete_static_BG_(288 x 208).png" width="288" height="208"/>
</tileset>
