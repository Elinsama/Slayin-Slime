<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Terrain16x16" tilewidth="16" tileheight="16" tilecount="170" columns="17">
 <image source="../../../../../../../../../Resources/Graphics/Tileset/Seasonal Tilesets/Autumn Forest/Terrain (16 x 16).png" width="272" height="160"/>
</tileset>
