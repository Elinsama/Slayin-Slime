<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="Flowers16x16" tilewidth="16" tileheight="16" tilecount="4" columns="4">
 <image source="../../../../../../../../../Resources/Graphics/Tileset/Seasonal Tilesets/Misc. universal tiles/Flowers (16 x 16).png" width="64" height="16"/>
</tileset>
